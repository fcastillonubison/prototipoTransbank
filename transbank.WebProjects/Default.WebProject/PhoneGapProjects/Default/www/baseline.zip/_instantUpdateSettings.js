function _instantUpdateSettings() {
return {
	"baseLineGUID": "0d5658cb26b74a1395c8c10a5e7646c2",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose"
};
}