function _instantUpdateSettings() {
return {
	"baseLineGUID": "bf8358ab790647329cccb8eb26fd20cb",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": true,
	"message": "actualizado {version}",
	"systemMessages": "Verbose"
};
}